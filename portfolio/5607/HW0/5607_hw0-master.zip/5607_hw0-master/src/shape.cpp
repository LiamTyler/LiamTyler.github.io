#include "include/shape.h"

Shape::Shape(int n, float angle, float edge, float RPS, int tu) {
    num_vertices_ = n;
    vertices_ = new float[n*2];
    texCoords_ = new float[n*2];
    color_[0] = -1;
    color_[1] = -1;
    color_[2] = -1;
    angle_ = angle;
    old_angle_ = 0;
    edge_ = edge;
    RPS_ = RPS;
    translating_ = rotating_ = scaling_ = false;
    tex_unit_ = tu;
}

Shape::~Shape() {
    glDeleteBuffers(1, &vbo_); 
    glDeleteVertexArrays(1, &vao_);
    delete [] vertices_;
    delete [] texCoords_;
}

void Shape::Init(GLuint shader) {
    glGenVertexArrays(1, &vao_); 
    glBindVertexArray(vao_);

    glGenBuffers(1, &vbo_);
    glBindBuffer(GL_ARRAY_BUFFER, vbo_);
    glBufferData(GL_ARRAY_BUFFER, GetVertexBufSize(), GetVertices(), GL_DYNAMIC_DRAW);
    GLint posAttrib = glGetAttribLocation(shader, "position");
    glVertexAttribPointer(posAttrib, 2, GL_FLOAT, GL_FALSE, 0, 0);
    glEnableVertexAttribArray(posAttrib);
    glBindBuffer(GL_ARRAY_BUFFER, vbo_);
}

void Shape::Draw(GLuint shader, bool tex) {
    glBindVertexArray(vao_);
    glBindBuffer(GL_ARRAY_BUFFER, vbo_);
    glBufferData(GL_ARRAY_BUFFER, GetVertexBufSize(), GetVertices(), GL_DYNAMIC_DRAW);
    if (tex) {
        color_[0] = -1;
        ActivateTexture();
    }
    GLint loc = glGetUniformLocation(shader, "triangleColor");
    glUniform3f(loc, color_[0], color_[1], color_[2]);
    glDrawArrays(GL_TRIANGLE_STRIP, 0, GetNumVertices());
}

void Shape::Update(float screen_width, float screen_height) {}

bool Shape::mouseClicked(float mx, float my) { return false; }
bool Shape::mouseDragged(float mx, float my) { return false; }

int Shape::GetVertexBufSize() { return num_vertices_ * 2 * sizeof(float); }

int Shape::GetTexCoordBufSize() { return num_vertices_ * 2 * sizeof(float); }

void Shape::EndMovement() {
    translating_ = false;
    scaling_ = false;
    rotating_ = false;
    color_[0] = 0;
    color_[1] = 0;
    color_[2] = 1;
}

float * Shape::GetVertices() { return vertices_; }

float * Shape::GetTexCoords() { return texCoords_; }

int Shape::GetNumVertices() { return num_vertices_; }

void Shape::ToggleAnimation() { animating_ = !animating_; }

void Shape::LoadTexture(GLuint program) {
    texture_ = loadTexture(texture_path_);
    glActiveTexture(GL_TEXTURE0 + tex_unit_);
    glBindTexture(GL_TEXTURE_2D, texture_);
    uniform_ = glGetUniformLocation(program, tex_name_.c_str());
    glUniform1i(uniform_, tex_unit_);

    glGenBuffers(1, &texBuf_);
    glBindBuffer(GL_ARRAY_BUFFER, texBuf_);
    glBufferData(GL_ARRAY_BUFFER, GetTexCoordBufSize(), GetTexCoords(), GL_STATIC_DRAW);
    texAttrib_ = glGetAttribLocation(program, tex_coords_name_.c_str());
    glEnableVertexAttribArray(texAttrib_);
    glVertexAttribPointer(texAttrib_, 2, GL_FLOAT, GL_FALSE, 0, 0);
}

void Shape::ActivateTexture() {
    glActiveTexture(GL_TEXTURE0 + tex_unit_);
    glBindTexture(GL_TEXTURE_2D, texture_);
    glUniform1i(uniform_, tex_unit_);
}

void Shape::SetTextureInfo(std::string path, std::string texName,
        std::string texCoordsName, int texUnit) {
    texture_path_ = path;
    tex_name_ = texName;
    tex_coords_name_ = texCoordsName;
    tex_unit_ = texUnit;
}
