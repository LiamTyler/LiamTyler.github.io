#include "include/triangle.h"

Triangle::Triangle(int tu) : Shape(3, 0, 5, .2, tu) {
    p0 = Point(300, 300);
    p1 = Point(300, 500);
    p2 = Point(500, 500);
    old_scale_ = 0;
    UpdateVertexPos();
    SetTextureCoords();
}

void Triangle::SetTextureCoords() {
    texCoords_[0] = 0;
    texCoords_[1] = 1;

    texCoords_[2] = 0;
    texCoords_[3] = 0;

    texCoords_[4] = 1;
    texCoords_[5] = 0;
}

void Triangle::Move(float dx, float dy) {
    p0.x += dx;
    p0.y += dy;

    p1.x += dx;
    p1.y += dy;

    p2.x += dx;
    p2.y += dy;
}

void Triangle::UpdateVertexPos() {
    vertices_[0] = p0.x;
    vertices_[1] = p0.y;

    vertices_[2] = p1.x;
    vertices_[3] = p1.y;

    vertices_[4] = p2.x;
    vertices_[5] = p2.y;
}

void Triangle::UpdateVertices(float screen_width, float screen_height) {
    UpdateVertexPos();
    // convert center to [-1, 1]
    Point c = GetCentroid();
    c.x = 2*c.x/screen_width - 1;
    c.y = 1- 2*c.y/screen_height;
    // convert to [-1, 1] range
    for (int i = 0; i < 6; i += 2) {
        vertices_[i] *= screen_width / 800.0;
        vertices_[i+1] *= screen_height/ 800.0;

        vertices_[i] = 2*vertices_[i]/screen_width - 1;
        vertices_[i+1] = 1 - 2*vertices_[i+1]/screen_height;
    }
    // translate to 0,0
    for (int i = 0; i < 6; i += 2) {
        vertices_[i] -= c.x ;
        vertices_[i+1] -= c.y; 
    }
    // rotate
    for (int i = 0; i < 6; i += 2) {
        float x = vertices_[i];
        float y = vertices_[i+1];
        vertices_[i] = x*std::cos(angle_) - y*std::sin(angle_);
        vertices_[i+1] = x*std::sin(angle_) + y*std::cos(angle_);
    }
    // translate back
    for (int i = 0; i < 6; i += 2) {
        vertices_[i] += c.x ;
        vertices_[i+1] += c.y; 
    }
}

void Triangle::Update(float screen_width, float screen_height) {
    UpdateVertices(screen_width, screen_height);
}

Point Triangle::GetCentroid() {
    float cx = (p0.x + p1.x + p2.x) / 3.0;
    float cy = (p0.y + p1.y + p2.y) / 3.0;
    return Point(cx, cy);
}

// point inside triangle detection gotten from andreasdr's answer on SO:
// https://stackoverflow.com/questions/2049582/how-to-determine-if-a-point-is-in-a-2d-triangle
bool Triangle::mouseClicked(float mx, float my) {
    Point cp = GetCentroid();
    // unrotate mouse points
    float umx = mx - cp.x;
    float umy = cp.y - my;
    mx = umx*std::cos(-angle_) - umy*std::sin(-angle_) + cp.x;
    my = cp.y - (umx*std::sin(-angle_) + umy*std::cos(-angle_));

    // detect if inside triangle
    float area = 0.5 * (-p1.y*p2.x + p0.y*(-p1.x + p2.x) +
            p0.x*(-p1.y + p2.y) + p1.x*p2.y);
    float s = 1/(2*area) * (p0.y*p2.x - p0.x*p2.y +
            (p2.y - p0.y)*mx + (p0.x - p2.x)*my);
    float t = 1/(2*area) * (p0.x*p1.y - p0.y*p1.x +
            (p0.y - p1.y)*mx + (p1.x - p0.x)*my);
    if (!(s>0 && t>0 && 1-s-t>0))
        return false;

    Point m(mx, my);
    // See if grabbing a corner
    float a = DistanceBetween(p0, m);
    float b = DistanceBetween(p1, m);
    float c = DistanceBetween(p2, m);
    if (a < 2*edge_) {
        rotating_ = true;
    } else if (b < 2*edge_) {
        rotating_ = true;
    } else if (c < 2*edge_) {
        rotating_ = true;
    }
    if (rotating_) {
        old_angle_ = std::atan2(my - cp.y, mx - cp.x);
        return true;
    }

    // detect if clicking edge
    // get distance from point to each edge
    float v01 = ClosestDistance(p0, p1, m);
    float v02 = ClosestDistance(p0, p2, m);
    float v12 = ClosestDistance(p1, p2, m);
    if (v01 < edge_) {
        scaling_ = true;
    } else if (v02 < edge_) {
        scaling_ = true;
    } else if (v12 < edge_) {
        scaling_ = true;
    }
    if (scaling_) {
        old_scale_ = DistanceBetween(cp, m);
        return true;
    }

    translating_ = true;
    rotating_ = false;
    scaling_ = false;
    return true;
}

bool Triangle::mouseDragged(float mx, float my) {
    Point c = GetCentroid();
    if (translating_) {
        float dx = mx - c.x;
        float dy = my - c.y;
        Move(dx, dy);
        return true;
    }
    float umx = mx - c.x;
    float umy = c.y - my;
    mx = umx*std::cos(-angle_) - umy*std::sin(-angle_) + c.x;
    my = c.y - (umx*std::sin(-angle_) + umy*std::cos(-angle_));
    if (rotating_) {
        float a = std::atan2(my - c.y, mx - c.x);
        float da = a - old_angle_;
        angle_ -= da;
    }

    if (scaling_) { 
        Point m(mx, my);
        float d = DistanceBetween(m, c);
        // limit how far you can shrink it
        if (d < edge_ * 2)
            return true;
        float s = d / old_scale_;
        // scale the points by whatever the change is
        Move(-c.x, -c.y);
        p0.x *= s;
        p0.y *= s;
        p1.x *= s;
        p1.y *= s;
        p2.x *= s;
        p2.y *= s;
        Move(c.x, c.y);
        old_scale_ = d;
    }
    return true;
}
