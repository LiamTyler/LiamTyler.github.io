#ifndef SHAPE_H_
#define SHAPE_H_

#include <iostream>
#include <cstdint>
#include <cmath>
#include "include/utils.h"

class Shape {
    public:
        Shape(int n, float angle, float edge, float RPS, int tu);
        virtual ~Shape();
        void Init(GLuint shader);
        void Draw(GLuint shader, bool tex);
        virtual void Update(float screen_width, float screen_height);
        virtual bool mouseClicked(float mx, float my);
        virtual bool mouseDragged(float mx, float my);
        int GetVertexBufSize();
        int GetTexCoordBufSize();
        virtual void EndMovement();
        float * GetVertices();
        float * GetTexCoords();
        int GetNumVertices();
        void ToggleAnimation();
        void LoadTexture(GLuint program);
        void ActivateTexture();
        void SetTextureInfo(std::string path, std::string texName,
                            std::string texCoordsName, int texUnit);
        GLuint GetVBO() { return vbo_; }
        GLuint GetVAO() { return vao_; }

    protected:
        float *vertices_;
        float *texCoords_;
        int num_vertices_;
        float angle_;
        float old_angle_;
        float RPS_;
        float edge_;
        int time_;
        int old_time_;

        bool translating_;
        bool rotating_;
        bool scaling_;
        bool animating_;

        GLuint vao_;
        GLuint vbo_;

        Texture texture_;
        int tex_unit_;
        std::string texture_path_;
        std::string tex_name_;
        std::string tex_coords_name_;
        GLuint texBuf_;
        GLuint uniform_;
        GLint texAttrib_;

        float color_[3];
};

#endif  // SHAPE_H_

