#ifndef SQUARE_H_
#define SQUARE_H_

#include "include/shape.h"
#include <SDL2/SDL.h>

class Square : public Shape {
    public:
        Square();
        Square(float x, float y, int tu);
        Square(float x, float y, float w, float h, float edge, float angle, int tu);
        void EndMovement();
        void UpdateVertexPos();
        void UpdateVertices(float screen_width, float screen_height);
        void Update(float screen_width, float screen_height);
        bool mouseClicked(float m_x, float m_y);
        bool mouseDragged(float m_x, float m_y);
        void SetTextureCoords();

    protected:
        float x_;
        float y_;
        float w_;
        float h_;

        bool sl_;
        bool sr_;
        bool st_;
        bool sb_;
};

#endif  // SQUARE_H_
