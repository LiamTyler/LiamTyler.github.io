#include "include/utils.h"
#include "include/ParticleSystem.h"
#include "include/Camera.h"
#include "include/Plane.h"
#include "include/Sphere.h"

using namespace std;

int main(int arc, char** argv) {
    // Set random seed
    srand(time(NULL));
    // initialize SDL and GLEW and set up window
    SDL_Window* window = InitAndWindow("5611 HW1", 100, 100, 800, 600);
    cout << "vendor: " << glGetString(GL_VENDOR) << endl;
    cout << "renderer: " << glGetString(GL_RENDERER) << endl;
    cout << "version: " << glGetString(GL_VERSION) << endl;


    vector<GameObject*> sceneObjects;

    Plane plane(vec3(0, 0, 0), vec3(0, 0, 0), vec3(25, 1, 25), "textures/truchet.png");
    sceneObjects.push_back(&plane);

    // Sphere for fire
    sceneObjects.push_back(new Sphere(vec3(0, 0.7, -8), vec3(0, 0, 0), vec3(0.2, 0.2, 0.2), vec4(0.1, 0.4, 0.7, 1.0)));

    // Water interactions
    sceneObjects.push_back(new Plane(vec3(-5, 0.7, -5), vec3(radians(30.0f), 0, 0), vec3(0.45, 0.45, 0.45), vec4(0.2, 0.7, 0.2, 1.0)));
    sceneObjects.push_back(new Plane(vec3(-4.9, 0.3, -4.2), vec3(radians(-30.0f), 0, radians(-30.0f)), vec3(0.35, 0.35, 0.35), vec4(0.2, 0.7, 0.2, 1.0)));

    // Ball interactions
    sceneObjects.push_back(new Plane(vec3(5, 0.6, -5), vec3(radians(30.0f), 0, radians(45.0f)), vec3(0.45, 0.45, 0.45), vec4(0.7, 0.0, 0.2, 1.0)));

    // Smoke
    sceneObjects.push_back(new Sphere(vec3(-2, 0.0, -2), vec3(0, 0, 0), vec3(0.2, 0.2, 0.2), vec4(1.0, 1.0, 1.0, 1.0)));

    // Create firework launchers
    for (int x = 0; x < 10; x++) {
      sceneObjects.push_back(new Sphere(vec3(x, 0, 0), vec3(0, 0, 0), vec3(0.1, 0.1, 0.1), vec4(0.2, 0.2, 0.2, 1.0)));
    }

    // set up the particle system
    int maxBalls   = 100000;
    int maxFire    = 100000;
    int maxRegular = 100000;
    ParticleSystem* particleSystem = new ParticleSystem(maxBalls, maxFire, maxRegular);
    particleSystem->Setup();
    Camera camera = Camera(vec3(0, 1, 5), vec3(0, -1, -5), vec3(0, 1, 0), 4.0f, 0.005f);

    bool quit = false;
    SDL_Event event;
    float currTime = 0;
    float prevTime = 0;
    float fpsTime = 0;
    unsigned int frameCounter = 0;
    SDL_SetRelativeMouseMode(SDL_TRUE);

    float theta = 0;
    bool rotate = false;
    float sphereMoveRate = 0.001f;

    glEnable(GL_BLEND);
    while (!quit) {
        // Process all input events
        while (SDL_PollEvent(&event)) {
            if (event.type == SDL_QUIT) {
                quit = true;
            } else if (event.type == SDL_KEYDOWN && event.key.repeat == 0) {
                // key down events (wont repeat if holding key down)
                switch (event.key.keysym.sym) {
                    case SDLK_w:
                        camera.VelZ(1.0f);
                        break;
                    case SDLK_s:
                        camera.VelZ(-1.0f);
                        break;
                    case SDLK_a:
                        camera.VelX(-1.0f);
                        break;
                    case SDLK_d:
                        camera.VelX(1.0f);
                        break;
                    case SDLK_ESCAPE:
                        quit = true;
                        break;
                    case SDLK_p:
                        particleSystem->Pause();
                        break;
                    case SDLK_1:
                        particleSystem->Mode(0);
                        break;
                    case SDLK_2:
                        particleSystem->Mode(1);
                        break;
                    case SDLK_3:
                        particleSystem->Mode(2);
                        break;
                    case SDLK_4:
                        particleSystem->Mode(3);
                        break;
                    case SDLK_5:
                        particleSystem->Mode(4);
                        break;
                    case SDLK_f:
                        particleSystem->LaunchFirework();
                        break;
                    case SDLK_r:
                        rotate = !rotate;
                        break;
                    case SDLK_SPACE:
                        particleSystem->Emit(true);
                        break;
                }
            } else if (event.type == SDL_KEYUP) {
                // handle key up events
                switch (event.key.keysym.sym) {
                    case SDLK_w:
                    case SDLK_s:
                        camera.VelZ(0.0f);
                        break;
                    case SDLK_a:
                    case SDLK_d:
                        camera.VelX(0.0f);
                        break;
                    case SDLK_SPACE:
                        particleSystem->Emit(false);
                        break;
                }
            } else if (event.type == SDL_MOUSEMOTION) {
                // handle mouse events
                float dx = event.motion.xrel;
                float dy = event.motion.yrel;
                // Screen y corresponds to camera x
                camera.RotateX(-dy);
                camera.RotateY(-dx);
                camera.UpdateViewMatrix();
            }
        }


        // update particle system
        currTime = SDL_GetTicks() / 1000.0f;
        float dt = currTime - prevTime;

        // Move the sphere around
        const Uint8* keystate = SDL_GetKeyboardState(NULL);
        sphereMoveRate = 0.5*dt;
        if(keystate[SDL_SCANCODE_LEFT]) {
            sceneObjects[1]->PosX(-sphereMoveRate);
        }
        if(keystate[SDL_SCANCODE_RIGHT]) {
            sceneObjects[1]->PosX(sphereMoveRate);
        }
        if(keystate[SDL_SCANCODE_UP]) {
            sceneObjects[1]->PosZ(-sphereMoveRate);
        }
        if(keystate[SDL_SCANCODE_DOWN]) {
            sceneObjects[1]->PosZ(sphereMoveRate);
        }

        camera.Update(dt);
        particleSystem->Update(camera.Pos(), camera.Dir(), dt, sceneObjects);
        for (vector<GameObject*>::iterator obj = sceneObjects.begin();
            obj != sceneObjects.end(); ++obj) {
          (*obj)->Update(dt);
        }

        // Draw particle system
        // clear screen
        glClearColor(0, 0, 0, 0);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        mat4 VP = camera.ProjMatrix() * camera.ViewMatrix();
        for (vector<GameObject*>::iterator obj = sceneObjects.begin();
            obj != sceneObjects.end(); ++obj) {
          (*obj)->Draw(VP);
        }

        vec3 cr = camera.Right();
        vec3 cu = camera.Up();
        vec3 cd = camera.Dir();
        particleSystem->Draw(cd, cr, cu, VP);

        // swap windows and update time
        prevTime = currTime;
        ++frameCounter;
        if (currTime > fpsTime + 1) {
            int balls =   particleSystem->GetBallCount();
            int fire =    particleSystem->GetFireCount();
            int regular = particleSystem->GetRegularCount();
            cout << "FPS: " << frameCounter << endl;
            cout << "Particle Count: " << endl;
            cout << "\tBalls: " << balls << endl;
            cout << "\tFire: " << fire << endl;
            cout << "\tRegular: " << regular << endl;
            frameCounter = 0;
            fpsTime = currTime;
        }

        SDL_GL_SwapWindow(window);
    }

    // Clean up
    delete particleSystem;
    SDL_Quit();

    return 0;
}
