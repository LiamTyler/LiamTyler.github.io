#ifndef SRC_INCLUDE_FIREWORK_H_
#define SRC_INCLUDE_FIREWORK_H_

#include "include/utils.h"
#include "include/Particle.h"
#include "include/Emitter.h"
#include "include/GameObject.h"

class Firework {
  public:
    Firework();
    Firework(vec3 pos, vec3 vel, float detTime);
    ~Firework();

    void Setup();
    void Update(float dt);
    void Launch() { launch_ = true; };
    void Pos(vec3 pos) { pos_ = pos; };
    bool Dead() { return dead_; };

    void Emit(Particle* particles, const int& maxP, int& numP, float dt);
    void DrawLauncher(mat4& VP);

  protected:
    vec3 pos_;
    vec3 initPos_;
    vec3 vel_;
    float age_;
    float detTime_;
    bool dead_;
    bool launch_;

    Emitter* smokeTrailEmitter_;
    Emitter* colorTrailEmitter_;
    Emitter* colorExlosionEmitter_;
    Emitter* colorExlosionEmitter2_;
    Emitter* smokeExlosionEmitter_;

};

#endif // SRC_INCLUDE_FIREWORK_H_
