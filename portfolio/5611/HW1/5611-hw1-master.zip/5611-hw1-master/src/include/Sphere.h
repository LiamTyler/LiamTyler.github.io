#ifndef SRC_INCLUDE_SPHERE_H_
#define SRC_INCLUDE_SPHERE_H_

#include "include/GameObject.h"


static vector<vec3> verts;
static vector<vec3> norms;
static vector<vec2> texCoords;
static vector<unsigned int> indices;
static GLuint elementBuffer;
static GLuint verts_vbo;
static GLuint norms_vbo;
static GLuint sphere_vao;
static bool sphereObjectsLoaded;

class Sphere : public GameObject {
public:
  Sphere();
  Sphere(vec3 pos, vec3 rot, vec3 scale, vec4 color);
  // Sphere(vec3 pos, vec3 rot, vec3 scale, string texture);

  void Setup();
  void Update(float dt);
  void Draw(mat4 &VP);
  bool IsColliding(vec3 position, float radius, vec3& intersection, vec3&
      surfNormal);

  static void LoadVertexObjects() {
    if (sphereObjectsLoaded)
      return;
    cout << "Loading Sphere Vertex buffers/arrays" << endl;
    // Create the shader
    object_shader = LoadShaders(VERT_SHADER, FRAG_SHADER);
    glUseProgram(object_shader);


    glGenVertexArrays(1, &sphere_vao);
    glBindVertexArray(sphere_vao);

    float radius = 1;
    int numLat = 20;
    int numLong = 20;
    int numVerts = (numLat + 1) * (numLong + 1);
    verts.resize(numVerts);
    norms.resize(numVerts);
    texCoords.resize(numVerts);

    int i = 0;
    for (int currLat = 0; currLat < numLat + 1; currLat++) {
        for (int currLong = 0; currLong < numLong + 1; currLong++) {
            float theta = currLat / (float) numLat;
            float phi = currLong / (float) numLong;
            texCoords[i] = vec2(phi, 1.0f - theta);
            theta *= M_PI;
            phi *= 2 * M_PI;
            float x = radius * sin(theta) * cos(phi);
            float y = radius * sin(theta) * sin(phi);
            float z = radius * cos(theta);
            verts[i] = vec3(x, y, z);
            norms[i] = verts[i];
            i++;
        }
    }
    indices.resize(3 * 2 * numLat * numLong);
    i = 0;
    for (int currLat = 0; currLat < numLat; currLat++) {
        for (int currLong = 0; currLong < numLong; currLong++) {
            indices[i++] = (numLong + 1) * currLat + currLong;
            indices[i++] = (numLong + 1) * (currLat + 1) + currLong;
            indices[i++] = (numLong + 1) * (currLat + 1) + (currLong + 1);

            indices[i++] = (numLong + 1) * (currLat + 1) + (currLong + 1);
            indices[i++] = (numLong + 1) * currLat + (currLong + 1);
            indices[i++] = (numLong + 1) * currLat + currLong;
        }
    }


    // create and bind vbo
    glGenBuffers(1, &verts_vbo);
    glBindBuffer(GL_ARRAY_BUFFER, verts_vbo);
    glBufferData(GL_ARRAY_BUFFER, sizeof(vec3)*numVerts, &verts[0],
        GL_STATIC_DRAW);
    GLint posAttrib = glGetAttribLocation(object_shader, "inPos");
    glEnableVertexAttribArray(posAttrib);
    glVertexAttribPointer(posAttrib, 3, GL_FLOAT, GL_FALSE, 0, 0);

    // 2nd vbo for the normals
    glGenBuffers(1, &norms_vbo);
    glBindBuffer(GL_ARRAY_BUFFER, norms_vbo);
    glBufferData(GL_ARRAY_BUFFER, sizeof(vec3)*numVerts, &norms[0],
        GL_STATIC_DRAW);
    GLint normAttrib = glGetAttribLocation(object_shader, "inNorm");
    glEnableVertexAttribArray(normAttrib);
    glVertexAttribPointer(normAttrib, 3, GL_FLOAT, GL_FALSE, 0, 0);

    glGenBuffers(1, &elementBuffer);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, elementBuffer);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, indices.size() * sizeof(unsigned
          int), &indices[0], GL_STATIC_DRAW);

    // unbind vertex array and shader
    glBindVertexArray(0);
    glUseProgram(0);
    sphereObjectsLoaded = true;
  }


private:
};

#endif // SRC_INCLUDE_SPHERE_H_
