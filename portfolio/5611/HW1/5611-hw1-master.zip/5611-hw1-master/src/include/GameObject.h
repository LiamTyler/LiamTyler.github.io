#ifndef SRC_INCLUDE_GAMEOBJECT_H_
#define SRC_INCLUDE_GAMEOBJECT_H_

#include "include/utils.h"

const string VERT_SHADER = "shaders/object.vert";
const string FRAG_SHADER = "shaders/object.frag";
static GLuint object_shader;// = LoadShaders(VERT_SHADER, FRAG_SHADER);

class GameObject {
public:
  virtual void Setup() = 0;
  virtual void Update(float dt) = 0;
  virtual void Draw(mat4 &VP) = 0;
  virtual bool IsColliding(vec3 position, float radius, vec3& intersection,
      vec3& surfNormal) = 0;
  
  void Pos(vec3 pos) { pos_ = pos; }
  void PosX(float pos) { pos_.x += pos; }
  void PosZ(float pos) { pos_.z += pos; }

protected:
  mat4 model_;
  vec3 pos_;
  vec3 rot_;
  vec3 scale_;
  vec4 color_;
};

#endif // SRC_INCLUDE_GAMEOBJECT_H_
