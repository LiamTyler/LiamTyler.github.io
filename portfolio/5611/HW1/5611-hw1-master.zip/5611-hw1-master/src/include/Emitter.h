#ifndef SRC_INCLUDE_EMITTER_H_
#define SRC_INCLUDE_EMITTER_H_

#include "include/utils.h"
#include "include/Particle.h"

class Emitter {
  public:
    Emitter(
        float radius=1.0f,
        float rate=20.0f,
        vec3 pos=vec3(0, 0, 0),
        vec3 dir=vec3(0, 1, 0),
        vec3 right=vec3(1, 0, 0),
        vec3 up=vec3(0, 0, 1),
        float speed=1.0f,
        vec4 color=vec4(0, 0, 0, 1),
        float size=1.0f,
        float lifetime=5.0f,
        int type=0,
        float rotSpeed=0.0f,
        bool useGravity=false
    );
    ~Emitter();

    void Emit(Particle* particles, const int& maxP, int& numP, 
        float dt);

    virtual vec3 GetRandomPoint(vec3& dir) = 0;

    vec3 Pos() { return position_; }
    void Pos(vec3 pos) { position_ = pos; }
    vec3 Dir() { return direction_; }

  protected:
    float radius_;
    vec3 position_;
    vec3 direction_;
    vec3 right_;
    vec3 up_;
    float rate_;
    float speed_;
    vec4 color_;
    float size_;
    float lifetime_;
    int type_;
    float rotSpeed_;
    bool useGravity_;

    float error_;
};

#endif  // SRC_INCLUDE_EMITTER_H_
