#ifndef SRC_INCLUDE_CAMERA_H_
#define SRC_INCLUDE_CAMERA_H_

#include "include/utils.h"

// NOTE(BRIDGER): I just figured it would be nice to have a camera class, and sorta
// outlined the basis of one. Feel free to change whatever!
class Camera {
    public:
        Camera();
        Camera(vec3 pos, vec3 dir, vec3 up);
        Camera(vec3 pos, vec3 dir, vec3 up, float vel_linear, float vel_angular);

        void Setup();

        void SetProjection(float fov, float aspect, float near_plane,
            float far_plane);
        void SetView(vec3 pos, vec3 dir, vec3 up);

        // Frame-by-frame update
        void Update(float dt);

        // recalculate view matrix after moving / rotating
        void UpdateViewMatrix();

        // rotate about the Y axis
        void RotateY(float y);
        // rotate about the X axis
        void RotateX(float x);

        // Getters
        mat4 ViewMatrix() { return view_; }
        mat4 ProjMatrix() { return projection_; }
        vec3 Vel() { return vel_; }
        vec3 Pos() { return pos_; }
        vec3 Up() { return up_; }
        vec3 Right() { return right_; }
        vec3 Dir() { return dir_; }

        // Setters
        void VelX(float x) { vel_.x = x; }
        void VelY(float y) { vel_.y = y; }
        void VelZ(float z) { vel_.z = z; }
        void Vel(vec3 vel) { vel_ = vel; }
        void Pos(vec3 p) { pos_ = p; }


    private:
        vec3 pos_;
        vec3 dir_;
        vec3 up_;
        vec3 right_;
        vec3 vel_;

        float vel_angular_;
        float vel_linear_;

        vec2 rotation_; // maybe needed? rotation about the x, and y axis?

        mat4 view_;
        mat4 projection_;
};

#endif  // SRC_INCLUDE_CAMERA_H_
