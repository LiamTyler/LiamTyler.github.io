#ifndef SRC_INCLUDE_PARTICLE_SYSTEM_H_
#define SRC_INCLUDE_PARTICLE_SYSTEM_H_

#include "include/utils.h"
#include "include/Particle.h"
#include "include/Emitter.h"
#include "include/Firework.h"
#include "include/GameObject.h"

#define P_POS_AND_SIZES 0
#define P_ATTRIBS_BUFFER 1
#define P_COLORS 2
#define P_TOTAL_VBOS 3

class ParticleSystem {
  public:
    ParticleSystem(int maxBall, int maxFire, int maxReg);
    ~ParticleSystem();
    void Setup();
    void Pause() { running_ = !running_; }
    void Update(const vec3& cam, const vec3& cam_dir, const float& dt,
            const vector<GameObject*>& objects);
    void Emit(bool e) { emitting_ = e; }
    void LaunchFirework();
    void Mode(int mode) { currentEmitter_ = mode; };
    void Draw(vec3& camera_dir, vec3& camera_right, vec3& camera_up, mat4& VP);
    int GetBallCount() { return currentBalls_; }
    int GetFireCount() { return currentFire_; }
    int GetRegularCount() { return currentRegular_; }

  private:
    bool running_;
    bool emitting_;
    int maxBalls_;
    int maxFire_;
    int maxRegular_;
    int largestParticleCount_;
    int currentEmitter_;
    int currentFirework_;
    int currentBalls_;
    int currentFire_;
    int currentRegular_;

    Particle* ball_particles_;
    Particle* fire_particles_;
    Particle* regular_particles_;

    vec4* pAttribsBuffer1_;
    vec4* pAttribsBuffer2_;
    vec4* pAttribsBuffer3_;

    Emitter* ball_emitter_;
    Emitter* water_emitter_;
    Emitter* smoke_emitter_;
    Emitter* fire_emitter_;
    vector<Firework*> fireworks_;

    GLuint ball_shader_;
    GLuint fire_shader_;
    GLuint regular_shader_;
    GLuint object_shader_;
    GLuint ball_vao_;
    GLuint fire_vao_;
    GLuint regular_vao_;
    GLuint verts_vbo_;
    GLuint ball_vbo_[P_TOTAL_VBOS];
    GLuint fire_vbo_[P_TOTAL_VBOS];
    GLuint regular_vbo_[P_TOTAL_VBOS];

    GLuint normalTex_;
    GLuint fireColorMapTex_;
    GLuint fireShapeTex_;
    GLuint smokeShapeTex_;
    GLuint sparkleShapeTex_;
};

#endif  // SRC_INCLUDE_PARTICLE_SYSTEM_H_
