#ifndef SRC_INCLUDE_PARTICLE_H_
#define SRC_INCLUDE_PARTICLE_H_

#include "include/utils.h"

#define WATER 0
#define FIRE 1
#define SMOKE 2
#define SPARKLE 3
#define BALL 4

class Particle {
  public:
    Particle();
    Particle(vec3 p, vec3 v, vec4 c, float s, float lt, float ca);
    Particle(vec3 p, vec3 v, vec4 c, float s, float lt, float ca, float rs, vec3 goal);
    ~Particle();

    bool operator < (const Particle& other);

    vec3 pos;
    vec3 vel;
    vec4 color;
    vec3 goal;
    float size;
    float lifeTime;
    float invLifeTime;
    float currentAge;
    float rotSpeed;
    float distToCam;
    float type;
    bool useGravity;
    float bounce;
};

#endif  // SRC_INCLUDE_PARTICLE_H_
