
#ifndef SRC_INCLUDE_SPHERE_EMITTER_H_
#define SRC_INCLUDE_SPHERE_EMITTER_H_

#include "include/utils.h"
#include "include/Emitter.h"
#include "include/Particle.h"

class SphereEmitter : public Emitter {
  public:
    SphereEmitter(
      float radius=0.2f,
      float rate=4000.0f,
      vec3 pos=vec3(0, 1, 0),
      vec3 dir=vec3(0, 1, 0),
      vec3 right=vec3(1, 0, 0),
      vec3 up=vec3(0, 0, 1),
      float speed=1.0f,
      vec4 color=vec4(0, 0, 0, 1),
      float size=0.1f,
      float lifetime=5.0f,
      int type=FIRE,
      float rotSpeed=0.0f,
      bool useGravity=true
    );

    void Emit(Particle* particles, const int& maxP, int& numP, float dt);

    vec3 GetRandomPoint(vec3& dir);

};

#endif  // SRC_INCLUDE_SPHERE_EMITTER_H_
