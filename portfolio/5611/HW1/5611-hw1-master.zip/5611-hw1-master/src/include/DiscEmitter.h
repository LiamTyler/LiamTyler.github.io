#ifndef SRC_INCLUDE_DISC_EMITTER_H_
#define SRC_INCLUDE_DISC_EMITTER_H_

#include "include/utils.h"
#include "include/Emitter.h"
#include "include/Particle.h"

class DiscEmitter : public Emitter {
  public:
    DiscEmitter(
      float radius=0.1f,
      float rate=500.0f,
      vec3 pos=vec3(0, 2.2, 0),
      vec3 dir=vec3(0, 1, 0),
      vec3 right=vec3(1, 0, 0),
      vec3 up=vec3(0, 0, 1),
      float speed=0.5f,
      vec4 color=vec4(.2, .2, .2, .2),
      float size=0.1f,
      float lifetime=5.0f,
      int type=SMOKE,
      float rotSpeed=0.0f,
      bool useGravity=false
    );
    ~DiscEmitter();

    void Emit(Particle* particles, const int& maxP, int& numP, float dt);

    vec3 GetRandomPoint(vec3 &dir);
};

#endif  // SRC_INCLUDE_DISC_EMITTER_H_
