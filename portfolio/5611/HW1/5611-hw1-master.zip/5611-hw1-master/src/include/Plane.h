#ifndef SRC_INCLUDE_PLANE_H_
#define SRC_INCLUDE_PLANE_H_

#include "include/GameObject.h"

const static vector<vec3> planeVerts = {
      vec3(-1, 0, 1),
      vec3(1, 0,  1),
      vec3(-1, 0,-1),
      vec3(1, 0,  1),
      vec3(1, 0, -1),
      vec3(-1, 0,-1)
};
const static vector<vec3> planeNorms = {
    vec3(0, 1, 0),
    vec3(0, 1, 0),
    vec3(0, 1, 0),
    vec3(0, 1, 0),
    vec3(0, 1, 0),
    vec3(0, 1, 0)
};
static GLuint plane_vao;
static GLuint planeVerts_vbo;
static GLuint planeNorms_vbo;
static bool vertexObjectsLoaded;

class Plane : public GameObject {
public:
  Plane();
  Plane(vec3 pos, vec3 rot, vec3 scale, vec4 color);
  Plane(vec3 pos, vec3 rot, vec3 scale, string texture);

  void Setup();
  void Update(float dt);
  void Draw(mat4 &VP);
  bool IsColliding(vec3 position, float radius, vec3& intersection, 
      vec3& surfNormal);

  static void LoadVertexObjects() {
    if (vertexObjectsLoaded)
      return;
    cout << "Loading GameObject Vertex buffers/arrays" << endl;
    // Create the shader
    object_shader = LoadShaders(VERT_SHADER, FRAG_SHADER);
    glUseProgram(object_shader);

    // create and bind plane vao
    glGenVertexArrays(1, &plane_vao);
    glBindVertexArray(plane_vao);
    glGenBuffers(1, &planeVerts_vbo);
    glBindBuffer(GL_ARRAY_BUFFER, planeVerts_vbo);

    // set up shader attributes
    glBufferData(GL_ARRAY_BUFFER, sizeof(vec3)*6, &planeVerts[0],
        GL_STATIC_DRAW);

    GLuint posAttrib = glGetAttribLocation(object_shader, "inPos");
    glEnableVertexAttribArray(posAttrib);
    glVertexAttribPointer(posAttrib, 3, GL_FLOAT, GL_FALSE, 0, 0);

    glGenBuffers(1, &planeNorms_vbo);
    glBindBuffer(GL_ARRAY_BUFFER, planeNorms_vbo);
    glBufferData(GL_ARRAY_BUFFER, sizeof(vec3)*6, &planeNorms[0],
        GL_STATIC_DRAW);

    GLuint normAttrib = glGetAttribLocation(object_shader, "inNorm");
    glEnableVertexAttribArray(normAttrib);
    glVertexAttribPointer(normAttrib, 3, GL_FLOAT, GL_FALSE, 0, 0);

    // unbind vertex array and shader
    glBindVertexArray(0);
    glUseProgram(0);
    vertexObjectsLoaded = true;
  }


private:
  string tex_name;
  GLuint plane_tex;
};

#endif // SRC_INCLUDE_PLANE_H_
