#include "include/Particle.h"

Particle::Particle() : Particle(
    vec3(0, 0, 0),
    vec3(0, 0, 0),
    vec4(0, 0, 0, 1),
    1,
    5,
    -1) {}

Particle::Particle(vec3 p, vec3 v, vec4 c, float s, float lt, float ca) :
    Particle(p, v, c, s, lt, ca, 0, vec3(0, 0, 0)) {
}

Particle::Particle(vec3 p, vec3 v, vec4 c, float s, float lt, float ca,
        float rs, vec3 g) {
    pos = p;
    vel = v;
    color = c;
    size = s;
    lifeTime = lt;
    invLifeTime = 1.0f / lt;
    currentAge = ca;
    rotSpeed = rs;
    distToCam = 0;
    goal = g;
    useGravity = true;
    bounce = 0.1f;
}

bool Particle::operator < (const Particle& other) {
    return distToCam > other.distToCam;
}

Particle::~Particle() {}
