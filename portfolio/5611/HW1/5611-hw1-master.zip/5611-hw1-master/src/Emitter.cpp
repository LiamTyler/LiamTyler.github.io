#include "include/Emitter.h"

Emitter::Emitter(
      float radius,
      float rate,
      vec3 pos,
      vec3 dir,
      vec3 right,
      vec3 up,
      float speed,
      vec4 color,
      float size,
      float lifetime,
      int type,
      float rotSpeed,
      bool useGravity
    ) {

    radius_ = radius;
    position_ = pos;
    direction_ = dir;
    right_ = right;
    up_ = up;
    rate_ = rate;
    speed_ = speed;
    color_ = color;
    size_ = size;
    lifetime_ = lifetime;
    error_ = 0;
    type_ = type;
    rotSpeed_ = rotSpeed;
    useGravity_ = useGravity;
}

Emitter::~Emitter() {}

void Emitter::Emit(Particle* particles, const int& maxP, int& numP, float dt)
    {
    float generate = dt * rate_ + error_;
    int pToGen = (int) generate;
    vec3 pVel = direction_ * speed_;
    error_ = generate - pToGen;
    vec3 goal = position_ + 1.5 * direction_;
    for (int i = numP; i < numP + pToGen && i < maxP; i++) {
      Particle p;
      vec3 dir;
      vec3 pos = GetRandomPoint(dir);
      if (type_ == FIRE) {
        // select random velocity perturbation
        float randSpeed = speed_ * ((rand() / (float) RAND_MAX) + .3);
        vec3 velocity = randSpeed * dir;
        float rotSpeed = 6*(rand() / (float) RAND_MAX + .1) - 3.3;

        // create the particle
        p = Particle(pos, velocity, color_, size_, lifetime_, 0, rotSpeed,
            goal);
        p.bounce = 0.05f;
      }
      else if (type_ == SMOKE) {
        // select random velocity perturbation
        float radius2 = 5 * radius_ * sqrt(((float) rand())/RAND_MAX);
        float theta2 = ((float) rand())/RAND_MAX * 2.0f*M_PI;
        float x2 = radius2 * cos(theta2);
        float y2 = radius2 * sin(theta2);
        // vec3 velocity = speed_ * .9f * direction_ + x2 * right_ + y2 * up_;
        vec3 velocity = speed_ * .9f * dir + x2 * right_ + y2 * up_;
        p = Particle(pos, velocity, color_, size_, lifetime_, 0);
        p.rotSpeed = 6 * (rand() / (float) RAND_MAX + .1) - 3.3;
        p.bounce = 0.05f;
      }
      else if (type_ == SPARKLE) {
        // select random velocity perturbation
        float radius2 = 5 * radius_ * sqrt(((float) rand())/RAND_MAX);
        float theta2 = ((float) rand())/RAND_MAX * 2.0f*M_PI;
        float x2 = radius2 * cos(theta2);
        float y2 = radius2 * sin(theta2);
        // vec3 velocity = speed_ * .9f * direction_ + x2 * right_ + y2 * up_;
        vec3 velocity = speed_ * .9f * dir + x2 * right_ + y2 * up_;

        // create the particle
        p = Particle(pos, velocity, color_, size_, lifetime_, 0);
        p.rotSpeed = rotSpeed_ * ((((float) rand())/RAND_MAX * 2.0f) + 1.0f);
        p.bounce = 0.05f;
      }
      else if (type_ == BALL) {
        vec3 velocity = speed_ * .9f * dir;
        p = Particle(pos, velocity, color_, size_, lifetime_, 0);
        p.bounce = 0.9f;
      }
      else if (type_ == WATER) {
        vec3 velocity = speed_ * .9f * dir;
        p = Particle(pos, velocity, color_, size_, lifetime_, 0);
        // p.bounce = 0.4f;
      }
      else {
        vec3 velocity = speed_ * .9f * dir;
        p = Particle(pos, velocity, color_, size_, lifetime_, 0);
      }
      p.type = type_;
      p.useGravity = useGravity_;
      particles[i] = p;
    }
    numP = std::min(maxP, numP + pToGen);
}
