#include "include/Plane.h"

Plane::Plane() : Plane(
  vec3(0, 0, 0),
  vec3(0, 0, 0),
  vec3(1, 1, 1),
  vec4(0, 0, 0, 1)
) {}

Plane::Plane(vec3 pos, vec3 rot, vec3 scale, vec4 color) {
  pos_ = pos;
  rot_ = rot;
  scale_ = scale;
  color_ = color;
  Setup();
}

Plane::Plane(vec3 pos, vec3 rot, vec3 scale, string texture) {
  pos_ = pos;
  rot_ = rot;
  scale_ = scale;
  color_ = vec4(0, 0, 0, 0);
  tex_name = texture;
  Setup();
}


void Plane::Setup() {
  model_ = mat4(1);
  model_ = translate(model_, pos_);
  model_ = rotate(model_, rot_.z, vec3(0, 0, 1));
  model_ = rotate(model_, rot_.x, vec3(1, 0, 0));
  model_ = rotate(model_, rot_.y, vec3(0, 1, 0));
  model_ = scale(model_, scale_);

  LoadVertexObjects();

  if (!tex_name.empty()) {
    plane_tex = LoadTexture(tex_name);
  }
}

void Plane::Update(float dt) {
}

void Plane::Draw(mat4 &VP) {
  glUseProgram(object_shader);
  GLint uniVP = glGetUniformLocation(object_shader, "VP");
  GLint uniModel = glGetUniformLocation(object_shader, "model");
  GLint uniScale = glGetUniformLocation(object_shader, "scale");
  glUniformMatrix4fv(uniVP, 1, GL_FALSE, value_ptr(VP));
  glUniformMatrix4fv(uniModel, 1, GL_FALSE, value_ptr(model_));
  glUniform3fv(uniScale, 1, value_ptr(scale_));

  // bind and draw floor
  glBindVertexArray(plane_vao);
  glActiveTexture(GL_TEXTURE0);
  glBindTexture(GL_TEXTURE_2D, plane_tex);
  glUniform1i(glGetUniformLocation(object_shader, "tex"), 0);

  glUniform4fv(glGetUniformLocation(object_shader, "color"), 1,
      value_ptr(color_));

  glDrawArrays(GL_TRIANGLES, 0, 6);

  // unbind vertex array and shader
  glBindVertexArray(0);
  glUseProgram(0);
}

bool Intersects(vec3 vertex0, vec3 vertex1, vec3 vertex2, vec3 position, float
    radius, vec3& intersection, vec3& surfNormal) {

  const float EPSILON = 0.0000001; 
  vec3 edge1, edge2, edge3, edge4, h, s, q;
  float a, f, u, v;
  edge1 = vertex1 - vertex0;
  edge2 = vertex2 - vertex0;

  h = cross(surfNormal, edge2);
  a = dot(edge1, h);
  if (a > -EPSILON && a < EPSILON)
      return false;
  f = 1/a;
  s = position - vertex0;
  u = f * (dot(s, h));
  if (u < 0.0 || u > 1.0)
      return false;
  q = cross(s, edge1);
  v = f * dot(surfNormal, q);
  if (v < 0.0 || u + v > 1.0)
      return false;
  // At this stage we can compute t to find out where the intersection point
  // is on the line.
  float t = f * dot(edge2, q);
  if (t > EPSILON) // ray intersection
  {
      intersection = position + surfNormal * t; 
      return true;
  }
  // This means that there is a line intersection but not a ray intersection.
  else
    return false;
}

// SOURCE: https://en.wikipedia.org/wiki/M%C3%B6ller%E2%80%93Trumbore_intersection_algorithm
bool Plane::IsColliding(vec3 position, float radius, vec3& intersection,
    vec3& surfNormal) {
  // Find the direction towards the plane
  surfNormal = normalize(vec3(model_*vec4(planeNorms[0], 0)));

  vec3 vertex0 = vec3(model_*vec4(planeVerts[0], 1));
  vec3 vertex1 = vec3(model_*vec4(planeVerts[1], 1));
  vec3 vertex2 = vec3(model_*vec4(planeVerts[2], 1));
  vec3 vertex3 = vec3(model_*vec4(planeVerts[3], 1));
  vec3 vertex4 = vec3(model_*vec4(planeVerts[4], 1));
  vec3 vertex5 = vec3(model_*vec4(planeVerts[5], 1));

  return Intersects(vertex0, vertex1, vertex2, position, radius, intersection,
      surfNormal) || Intersects(vertex3, vertex4, vertex5, position, radius,
        intersection, surfNormal);
}
