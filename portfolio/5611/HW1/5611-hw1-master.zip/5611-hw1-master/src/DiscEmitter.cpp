#include "include/DiscEmitter.h"


DiscEmitter::DiscEmitter(
    float radius,
    float rate,
    vec3 pos,
    vec3 dir,
    vec3 right,
    vec3 up,
    float speed,
    vec4 color,
    float size,
    float lifetime,
    int type,
    float rotSpeed,
    bool useGravity
) : Emitter(radius, rate, pos, dir, right, up, speed, color, size, lifetime, type,
  rotSpeed, useGravity) {
}

DiscEmitter::~DiscEmitter() {}

vec3 DiscEmitter::GetRandomPoint(vec3& dir) {
  float radius = radius_ * ((float) rand())/RAND_MAX;
  // cout << "Radius " << radius << endl;
  // cout << "Radius_ " << radius_ << endl;
  float theta = ((float) rand())/RAND_MAX * 2.0f*M_PI;
  float x = radius * cos(theta);
  float y = radius * sin(theta);
  dir = direction_;
  vec3 pos = position_ + x * right_ + y * up_;
  return pos;
}
