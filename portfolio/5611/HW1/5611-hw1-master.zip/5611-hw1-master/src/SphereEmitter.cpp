#include "include/SphereEmitter.h"

SphereEmitter::SphereEmitter(
      float radius,
      float rate,
      vec3 pos,
      vec3 dir,
      vec3 right,
      vec3 up,
      float speed,
      vec4 color,
      float size,
      float lifetime,
      int type,
      float rotSpeed,
      bool useGravity
) : Emitter(
      radius,
      rate,
      pos,
      dir,
      right,
      up,
      speed,
      color,
      size,
      lifetime,
      type,
      rotSpeed,
      useGravity
) {}

// SOURCE: http://mathworld.wolfram.com/SpherePointPicking.html
vec3 SphereEmitter::GetRandomPoint(vec3 &dir) {
  float theta = (rand() / (float) RAND_MAX) * 2.0f * M_PI;
  float u = (2.0f*(rand() / (float) RAND_MAX)) - 1.0f;
  float x = sqrt(1.0f - pow(u, 2.0f)) * cos(theta);
  float y = sqrt(1.0f - pow(u, 2.0f)) * sin(theta);
  dir = x * right_ + y * up_ + u * direction_;
  vec3 pos = position_ + dir;
  return pos;
}
