#include "include/ParticleSystem.h"
#include "include/DiscEmitter.h"
#include "include/HemisphereEmitter.h"
#include "include/SphereEmitter.h"
#include <omp.h>
#include <algorithm>

// #define REFLECTIVITY 0.9
#define NAIVE_COLLISIONS 0
#define GRAVITY vec3(0, -9.8, 0)
#define FRICTION 0.997

ParticleSystem::ParticleSystem(int maxB, int maxF, int maxR) {
    maxBalls_ = maxB;
    maxFire_ = maxF;
    maxRegular_ = maxR;
    largestParticleCount_ = std::max(maxB, std::max(maxF, maxR));
    currentBalls_ = 0;
    currentFire_ = 0;
    currentRegular_ = 0;

    ball_particles_ = nullptr;
    fire_particles_ = nullptr;
    regular_particles_ = nullptr;
    pAttribsBuffer1_ = nullptr;
    pAttribsBuffer2_ = nullptr;
    pAttribsBuffer3_ = nullptr;

    running_ = true;
    emitting_ = false;
    currentEmitter_ = 0;
    currentFirework_ = 0;

    fireworks_.resize(10);
    int x = 0;
    for (int i = 0; i < fireworks_.size(); i++) {
      fireworks_[i] = new Firework;
      fireworks_[i]->Pos(vec3(x, 0, 0));
      x++;
    }
    currentFirework_ = 0;
}

ParticleSystem::~ParticleSystem() {
    // delete particle arrays
    if (ball_particles_)
        delete [] ball_particles_;
    if (fire_particles_)
        delete [] fire_particles_;
    if (regular_particles_)
        delete [] regular_particles_;

    // delete particle attrib arrays
    if (pAttribsBuffer1_)
        delete [] pAttribsBuffer1_;
    if (pAttribsBuffer2_)
        delete [] pAttribsBuffer2_;
    if (pAttribsBuffer3_)
        delete [] pAttribsBuffer3_;

    for (int i = 0; i < fireworks_.size(); i++) {
      if (fireworks_[i])
          delete fireworks_[i];
    }
}

void ParticleSystem::Setup() {
    // allocate arrays
    ball_particles_ = new Particle[maxBalls_];
    fire_particles_ = new Particle[maxFire_];
    regular_particles_ = new Particle[maxRegular_];
    pAttribsBuffer1_ = new vec4[largestParticleCount_];
    pAttribsBuffer2_ = new vec4[largestParticleCount_];
    pAttribsBuffer3_ = new vec4[largestParticleCount_];

    // Load the shaders and set the active shader program
    ball_shader_ = LoadShaders("shaders/ball_shader.vert", "shaders/ball_shader.frag");
    fire_shader_ = LoadShaders("shaders/fire_shader.vert", "shaders/fire_shader.frag");
    regular_shader_ = LoadShaders("shaders/regular_shader.vert",
                                  "shaders/regular_shader.frag");

    // create and bind particle system vao
    glGenVertexArrays(1, &ball_vao_);
    glGenVertexArrays(1, &fire_vao_);
    glGenVertexArrays(1, &regular_vao_);

    static const GLfloat quad_verts[] = {
        -.5f, .5f, 0.0f,
        -.5f, -.5f, 0.0f,
        .5f, -.5f, 0.0f,
        .5f, -.5f, 0.0f,
        .5f, .5f, 0.0f,
        -.5f, .5f, 0.0f,
    };
    glGenBuffers(1, &verts_vbo_);
    glBindBuffer(GL_ARRAY_BUFFER, verts_vbo_);
    glBufferData(GL_ARRAY_BUFFER, sizeof(quad_verts), quad_verts,
            GL_STATIC_DRAW);

    glUseProgram(ball_shader_);
    glBindVertexArray(ball_vao_);

    // BALLS
    glGenBuffers(P_TOTAL_VBOS, ball_vbo_);
    glBindBuffer(GL_ARRAY_BUFFER, ball_vbo_[P_POS_AND_SIZES]);
    glBufferData(GL_ARRAY_BUFFER, maxBalls_ * sizeof(vec4), NULL,
            GL_STREAM_DRAW);
    glBindBuffer(GL_ARRAY_BUFFER, ball_vbo_[P_ATTRIBS_BUFFER]);
    glBufferData(GL_ARRAY_BUFFER, maxBalls_ * sizeof(vec4), NULL,
            GL_STREAM_DRAW);

    GLint vertAttrib = glGetAttribLocation(ball_shader_, "quadVerts");
    glEnableVertexAttribArray(vertAttrib);
    glBindBuffer(GL_ARRAY_BUFFER, verts_vbo_);
    glVertexAttribPointer(vertAttrib, 3, GL_FLOAT, GL_FALSE, 0, 0);

    GLint posAttrib = glGetAttribLocation(ball_shader_, "posAndSize");
    glEnableVertexAttribArray(posAttrib);
    glBindBuffer(GL_ARRAY_BUFFER, ball_vbo_[P_POS_AND_SIZES]);
    glVertexAttribPointer(posAttrib, 4, GL_FLOAT, GL_FALSE, 0, 0);

    glBindBuffer(GL_ARRAY_BUFFER, ball_vbo_[P_ATTRIBS_BUFFER]);
    GLint otherAttribs = glGetAttribLocation(ball_shader_, "inColor");
    glEnableVertexAttribArray(otherAttribs);
    glVertexAttribPointer(otherAttribs, 4, GL_FLOAT, GL_FALSE, 0, 0);

    glVertexAttribDivisor(vertAttrib, 0);
    glVertexAttribDivisor(posAttrib, 1);
    glVertexAttribDivisor(otherAttribs, 1);

    // FIRE
    glUseProgram(fire_shader_);
    glBindVertexArray(fire_vao_);

    glGenBuffers(P_TOTAL_VBOS, fire_vbo_);
    glBindBuffer(GL_ARRAY_BUFFER, fire_vbo_[P_POS_AND_SIZES]);
    glBufferData(GL_ARRAY_BUFFER, maxFire_ * sizeof(vec4), NULL,
            GL_STREAM_DRAW);
    glBindBuffer(GL_ARRAY_BUFFER, fire_vbo_[P_ATTRIBS_BUFFER]);
    glBufferData(GL_ARRAY_BUFFER, maxFire_ * sizeof(vec4), NULL,
            GL_STREAM_DRAW);

    vertAttrib = glGetAttribLocation(fire_shader_, "quadVerts");
    glEnableVertexAttribArray(vertAttrib);
    glBindBuffer(GL_ARRAY_BUFFER, verts_vbo_);
    glVertexAttribPointer(vertAttrib, 3, GL_FLOAT, GL_FALSE, 0, 0);

    posAttrib = glGetAttribLocation(fire_shader_, "posAndSize");
    glEnableVertexAttribArray(posAttrib);
    glBindBuffer(GL_ARRAY_BUFFER, fire_vbo_[P_POS_AND_SIZES]);
    glVertexAttribPointer(posAttrib, 4, GL_FLOAT, GL_FALSE, 0, 0);

    glBindBuffer(GL_ARRAY_BUFFER, fire_vbo_[P_ATTRIBS_BUFFER]);
    otherAttribs = glGetAttribLocation(fire_shader_, "inAgeLifeRotNone");
    glEnableVertexAttribArray(otherAttribs);
    glVertexAttribPointer(otherAttribs, 4, GL_FLOAT, GL_FALSE, 0, 0);

    glVertexAttribDivisor(vertAttrib, 0);
    glVertexAttribDivisor(posAttrib, 1);
    glVertexAttribDivisor(otherAttribs, 1);

    // REGULAR
    glUseProgram(regular_shader_);
    glBindVertexArray(regular_vao_);

    glGenBuffers(P_TOTAL_VBOS, regular_vbo_);
    glBindBuffer(GL_ARRAY_BUFFER, regular_vbo_[P_POS_AND_SIZES]);
    glBufferData(GL_ARRAY_BUFFER, maxRegular_ * sizeof(vec4), NULL,
            GL_STREAM_DRAW);
    glBindBuffer(GL_ARRAY_BUFFER, regular_vbo_[P_ATTRIBS_BUFFER]);
    glBufferData(GL_ARRAY_BUFFER, maxRegular_ * sizeof(vec4), NULL,
            GL_STREAM_DRAW);

    vertAttrib = glGetAttribLocation(regular_shader_, "quadVerts");
    glEnableVertexAttribArray(vertAttrib);
    glBindBuffer(GL_ARRAY_BUFFER, verts_vbo_);
    glVertexAttribPointer(vertAttrib, 3, GL_FLOAT, GL_FALSE, 0, 0);

    posAttrib = glGetAttribLocation(regular_shader_, "posAndSize");
    glEnableVertexAttribArray(posAttrib);
    glBindBuffer(GL_ARRAY_BUFFER, regular_vbo_[P_POS_AND_SIZES]);
    glVertexAttribPointer(posAttrib, 4, GL_FLOAT, GL_FALSE, 0, 0);

    glBindBuffer(GL_ARRAY_BUFFER, regular_vbo_[P_ATTRIBS_BUFFER]);
    otherAttribs = glGetAttribLocation(regular_shader_, "inAgeLifeRotType");
    glEnableVertexAttribArray(otherAttribs);
    glVertexAttribPointer(otherAttribs, 4, GL_FLOAT, GL_FALSE, 0, 0);

    glBindBuffer(GL_ARRAY_BUFFER, regular_vbo_[P_COLORS]);
    GLint colorAttrib = glGetAttribLocation(regular_shader_, "inColor");
    glEnableVertexAttribArray(colorAttrib);
    glVertexAttribPointer(colorAttrib, 4, GL_FLOAT, GL_FALSE, 0, 0);

    glVertexAttribDivisor(vertAttrib, 0);
    glVertexAttribDivisor(posAttrib, 1);
    glVertexAttribDivisor(otherAttribs, 1);
    glVertexAttribDivisor(colorAttrib, 1);


    // Load circle texture
    normalTex_ = LoadTexture("textures/normalTex.png");
    fireColorMapTex_ = LoadTexture("textures/fire.png");
    fireShapeTex_ = LoadTexture("textures/fire_tex2.png");
    smokeShapeTex_ = LoadTexture("textures/smoke2.png");
    sparkleShapeTex_ = LoadTexture("textures/firework.png");

    glBindVertexArray(0);
    glUseProgram(0);

    ball_emitter_ = new HemisphereEmitter(
            0.2f,
            300,
            vec3(5, 2, -5),
            vec3(0, 1, 0),
            vec3(1, 0, 0),
            vec3(0, 0, -1),
            8.0f,
            vec4(0, 1, 0, 1),
            .1f,
            5.0f,
            BALL,
            0,
            true);

    water_emitter_ = new HemisphereEmitter(
            0.2f,
            1000,
            vec3(-5, 1, -5),
            vec3(0, 1, 0),
            vec3(1, 0, 0),
            vec3(0, 0, -1),
            1.0f,
            vec4(0, .3, .8, 1),
            .1f,
            5.0f,
            WATER,
            0,
            true);

    smoke_emitter_ = new HemisphereEmitter(
            0.2f,
            3000,
            vec3(-2, 0.2, -2),
            vec3(0, 1, 0),
            vec3(1, 0, 0),
            vec3(0, 0, -1),
            4.0f,
            vec4(0, .3, .8, 1),
            .1f,
            5.0f,
            SMOKE,
            0,
            false);


    fire_emitter_ = new HemisphereEmitter(
      0.2f,
      4000.0f,
      vec3(0, 0.1, -8),
      vec3(0, 1, 0),
      vec3(1, 0, 0),
      vec3(0, 0, 1),
      1.0f,
      vec4(0, 0, 0, 1),
      0.1f,
      5.0f,
      FIRE,
      0.0f,
      false
    );
}

void ParticleSystem::LaunchFirework() {
  if (currentFirework_ >= fireworks_.size()) {
    currentFirework_ = 0;
    int x = 0;
    for (int i = 0; i < fireworks_.size(); i++) {
      if (fireworks_[i]->Dead()) {
        delete fireworks_[i];
        fireworks_[i] = new Firework;
        fireworks_[i]->Pos(vec3(x, 0, 0));
        x++;
      }
    }
  }
  fireworks_[currentFirework_++]->Launch();
}

void ParticleSystem::Update(const vec3& cam, const vec3& cam_dir, const float& dt,
        const vector<GameObject*>& objects) {
    if (running_) {
        for (int i = 0; i < fireworks_.size(); i++) {
          fireworks_[i]->Update(dt);
          fireworks_[i]->Emit(regular_particles_, maxRegular_,
              currentRegular_, dt);
        }
        if (emitting_) {
            switch (currentEmitter_) {
              case 0:
                ball_emitter_->Emit(ball_particles_, maxBalls_, currentBalls_, dt);
                fire_emitter_->Emit(fire_particles_, maxFire_, currentFire_, dt);
                water_emitter_->Emit(regular_particles_, maxRegular_, currentRegular_, dt);
                smoke_emitter_->Emit(regular_particles_, maxRegular_, currentRegular_, dt);
                break;
              case 1:
                water_emitter_->Emit(regular_particles_, maxRegular_, currentRegular_, dt);
                break;
              case 2:
                smoke_emitter_->Emit(regular_particles_, maxRegular_, currentRegular_, dt);
                break;
              case 3:
                fire_emitter_->Emit(fire_particles_, maxFire_, currentFire_, dt);
                break;
              case 4:
                ball_emitter_->Emit(ball_particles_, maxBalls_, currentBalls_, dt);
                break;
              default:
                break;
            }
        }
        Particle* pArrays[] = {ball_particles_, fire_particles_, regular_particles_};
        int* pNums[] = {&currentBalls_, &currentFire_, &currentRegular_};
        for (int currArrayIndex = 0; currArrayIndex < 3; currArrayIndex++) {
            Particle* currArray = pArrays[currArrayIndex];
            int* currNum = pNums[currArrayIndex];
            vector<int> deletes;
            omp_lock_t write_lock;
            omp_init_lock(&write_lock);

            int currP = *currNum;
            #pragma omp parallel for
            for (int i = 0; i < currP; i++) {
                Particle& p = currArray[i];
                p.currentAge += dt;
                if (p.currentAge >= p.lifeTime) {
                    omp_set_lock(&write_lock);
                    p.currentAge = p.lifeTime;
                    deletes.push_back(i);
                    omp_unset_lock(&write_lock);
                }
                p.pos += dt*p.vel;
                if (p.useGravity)
                  p.vel += dt*GRAVITY;
                
                if (NAIVE_COLLISIONS) {
                  if (p.pos.y - p.size / 2 < 0.0f) {
                    p.pos.y = p.size / 2;
                    p.vel.y = -p.vel.y*p.bounce;
                  }
                }
                else {
                  vec3 intersection, surfNormal;
                  for (vector<GameObject*>::const_iterator obj = objects.begin();
                      obj != objects.end(); ++obj) {
                    if ((*obj)->IsColliding(p.pos, p.size/2.0f, intersection,
                          surfNormal)) {
                      vec3 ref = reflect(p.vel, surfNormal);
                      if (p.type == WATER) {
                        vec3 refProj = proj(ref, surfNormal);
                        vec3 perp = ref - refProj;
                        p.vel = p.bounce*refProj + perp*FRICTION;
                      }
                      else
                        p.vel = p.bounce*ref;
                      p.pos = intersection;
                    }
                  }
                }
                if (p.type == FIRE) {
                    vec3 toGoal = p.goal - p.pos;
                    float speed = length(p.vel);
                    p.vel += dt*(.2f * normalize(toGoal));
                    p.vel = speed * normalize(p.vel);
                }
                p.distToCam = length(proj(p.pos - cam, cam_dir));
            }

            // remove old ones
            for (int i = 0; i < deletes.size(); i++) {
                --(*currNum);
                Particle p = currArray[deletes[i]];
                if (p.type == FIRE && length(p.vel) > .1) {
                    float r = .5 * (rand() / (float) RAND_MAX);
                    float t = 2.0f * M_PI * (rand() / (float) RAND_MAX);
                    float x = r * cos(t);
                    float y = r * cos(t);
                    float s = length(p.vel);
                    vec3 vel = s * normalize(vec3(x, 1, y));
                    Particle newP =
                        Particle(p.pos, vel, vec4(.2, .2, .2, .2),
                                .1f, 5, 0, p.rotSpeed, vec3(0, 0, 0));
                    newP.useGravity = false;
                    newP.type = SMOKE;
                    regular_particles_[currentRegular_++] = newP;
                }

                if (deletes[i] != *currNum)
                    currArray[deletes[i]] = currArray[*currNum];
            }
        }
    } else {
        Particle* pArrays[] = {ball_particles_, fire_particles_, regular_particles_};
        int pNums[] = {currentBalls_, currentFire_, currentRegular_};
        for (int currArrayIndex = 0; currArrayIndex < 3; currArrayIndex++) {
            Particle* currArray = pArrays[currArrayIndex];
            int currNum = pNums[currArrayIndex];

            #pragma omp parallel for
            for (int i = 0; i < currNum; i++) {
                Particle& p = currArray[i];
                p.distToCam = length(proj(p.pos - cam, cam_dir));
            }
        }
    }

    // sort
    std::sort(&regular_particles_[0], &regular_particles_[currentRegular_]);

    #pragma omp parallel for
    for (int i = 0; i < currentBalls_; i++) {
        Particle& p = ball_particles_[i];
        pAttribsBuffer1_[i] = vec4(p.pos, p.size);
        pAttribsBuffer2_[i] = p.color;
    }

    // update the vbos
    glBindBuffer(GL_ARRAY_BUFFER, ball_vbo_[P_POS_AND_SIZES]);
    glBufferData(GL_ARRAY_BUFFER, maxBalls_ * sizeof(vec4), NULL,
            GL_STREAM_DRAW);
    glBufferSubData(GL_ARRAY_BUFFER, 0, currentBalls_ * sizeof(vec4),
            pAttribsBuffer1_);
    glBindBuffer(GL_ARRAY_BUFFER, ball_vbo_[P_ATTRIBS_BUFFER]);
    glBufferData(GL_ARRAY_BUFFER, maxBalls_ * sizeof(vec4), NULL,
            GL_STREAM_DRAW);
    glBufferSubData(GL_ARRAY_BUFFER, 0, currentBalls_ * sizeof(vec4),
            pAttribsBuffer2_);

    #pragma omp parallel for
    for (int i = 0; i < currentFire_; i++) {
        Particle& p = fire_particles_[i];
        pAttribsBuffer1_[i] = vec4(p.pos, p.size);
        pAttribsBuffer2_[i] = vec4(p.currentAge, p.invLifeTime, p.rotSpeed, 0);
    }

    // update the vbos
    glBindBuffer(GL_ARRAY_BUFFER, fire_vbo_[P_POS_AND_SIZES]);
    glBufferData(GL_ARRAY_BUFFER, maxFire_ * sizeof(vec4), NULL,
            GL_STREAM_DRAW);
    glBufferSubData(GL_ARRAY_BUFFER, 0, currentFire_ * sizeof(vec4),
            pAttribsBuffer1_);
    glBindBuffer(GL_ARRAY_BUFFER, fire_vbo_[P_ATTRIBS_BUFFER]);
    glBufferData(GL_ARRAY_BUFFER, maxFire_ * sizeof(vec4), NULL,
            GL_STREAM_DRAW);
    glBufferSubData(GL_ARRAY_BUFFER, 0, currentFire_ * sizeof(vec4),
            pAttribsBuffer2_);

    #pragma omp parallel for
    for (int i = 0; i < currentRegular_; i++) {
        Particle& p = regular_particles_[i];
        pAttribsBuffer1_[i] = vec4(p.pos, p.size);
        pAttribsBuffer2_[i] = vec4(p.currentAge, p.invLifeTime, p.rotSpeed, p.type);
        pAttribsBuffer3_[i] = p.color;
    }

    // update the vbos
    glBindBuffer(GL_ARRAY_BUFFER, regular_vbo_[P_POS_AND_SIZES]);
    glBufferData(GL_ARRAY_BUFFER, maxRegular_ * sizeof(vec4), NULL,
            GL_STREAM_DRAW);
    glBufferSubData(GL_ARRAY_BUFFER, 0, currentRegular_ * sizeof(vec4),
            pAttribsBuffer1_);
    glBindBuffer(GL_ARRAY_BUFFER, regular_vbo_[P_ATTRIBS_BUFFER]);
    glBufferData(GL_ARRAY_BUFFER, maxRegular_ * sizeof(vec4), NULL,
            GL_STREAM_DRAW);
    glBufferSubData(GL_ARRAY_BUFFER, 0, currentRegular_ * sizeof(vec4),
            pAttribsBuffer2_);
    glBindBuffer(GL_ARRAY_BUFFER, regular_vbo_[P_COLORS]);
    glBufferData(GL_ARRAY_BUFFER, maxRegular_ * sizeof(vec4), NULL,
            GL_STREAM_DRAW);
    glBufferSubData(GL_ARRAY_BUFFER, 0, currentRegular_ * sizeof(vec4),
            pAttribsBuffer3_);
}

void ParticleSystem::Draw(vec3& camera_dir, vec3& camera_right,
        vec3& camera_up, mat4& VP) {
    // balls
    glUseProgram(ball_shader_);

    GLint uniVP = glGetUniformLocation(ball_shader_, "VP");
    glUniformMatrix4fv(uniVP, 1, GL_FALSE, value_ptr(VP));

    GLint cameraUp = glGetUniformLocation(ball_shader_, "cameraUp");
    GLint cameraRight = glGetUniformLocation(ball_shader_, "cameraRight");
    GLint cameraDir = glGetUniformLocation(ball_shader_, "cameraDir");
    glUniform3fv(cameraUp, 1, value_ptr(camera_up));
    glUniform3fv(cameraRight, 1, value_ptr(camera_right));
    glUniform3fv(cameraDir, 1, value_ptr(camera_dir));

    GLint uniNear = glGetUniformLocation(ball_shader_, "pNear");
    GLint uniFar = glGetUniformLocation(ball_shader_, "pFar");
    glUniform1f(uniNear, .1f);
    glUniform1f(uniFar, 100.0f);

    glBindVertexArray(ball_vao_);
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, normalTex_);
    glUniform1i(glGetUniformLocation(ball_shader_, "normalTex"), 0);

    glDrawArraysInstanced(GL_TRIANGLES, 0, 6, currentBalls_);

    // fire
    glBlendFunc(GL_SRC_ALPHA, GL_ONE);
    glDepthMask(GL_FALSE);
    glUseProgram(fire_shader_);

    uniVP = glGetUniformLocation(fire_shader_, "VP");
    glUniformMatrix4fv(uniVP, 1, GL_FALSE, value_ptr(VP));

    cameraUp = glGetUniformLocation(fire_shader_, "cameraUp");
    cameraRight = glGetUniformLocation(fire_shader_, "cameraRight");
    cameraDir = glGetUniformLocation(fire_shader_, "cameraDir");
    glUniform3fv(cameraUp, 1, value_ptr(camera_up));
    glUniform3fv(cameraRight, 1, value_ptr(camera_right));
    glUniform3fv(cameraDir, 1, value_ptr(camera_dir));

    glBindVertexArray(fire_vao_);
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, fireColorMapTex_);
    glUniform1i(glGetUniformLocation(fire_shader_, "colorMap"), 0);
    glActiveTexture(GL_TEXTURE0 + 1);
    glBindTexture(GL_TEXTURE_2D, fireShapeTex_);
    glUniform1i(glGetUniformLocation(fire_shader_, "fireShapeTex"), 1);

    glDrawArraysInstanced(GL_TRIANGLES, 0, 6, currentFire_);

    glDepthMask(GL_TRUE);

    // regular
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glUseProgram(regular_shader_);

    uniVP = glGetUniformLocation(regular_shader_, "VP");
    glUniformMatrix4fv(uniVP, 1, GL_FALSE, value_ptr(VP));

    cameraUp = glGetUniformLocation(regular_shader_, "cameraUp");
    cameraRight = glGetUniformLocation(regular_shader_, "cameraRight");
    cameraDir = glGetUniformLocation(regular_shader_, "cameraDir");
    glUniform3fv(cameraUp, 1, value_ptr(camera_up));
    glUniform3fv(cameraRight, 1, value_ptr(camera_right));
    glUniform3fv(cameraDir, 1, value_ptr(camera_dir));

    glBindVertexArray(regular_vao_);
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, smokeShapeTex_);
    glUniform1i(glGetUniformLocation(regular_shader_, "smokeShapeTex"), 0);
    glActiveTexture(GL_TEXTURE0 + 1);
    glBindTexture(GL_TEXTURE_2D, sparkleShapeTex_);
    glUniform1i(glGetUniformLocation(regular_shader_, "sparkleShapeTex"), 1);

    // glDepthFunc(GL_ALWAYS);
    glDrawArraysInstanced(GL_TRIANGLES, 0, 6, currentRegular_);

    // glDepthFunc(GL_LESS);

    glBindVertexArray(0);
    glUseProgram(0);
}
