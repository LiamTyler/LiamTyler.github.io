#include "include/Firework.h"
#include "include/DiscEmitter.h"
#include "include/SphereEmitter.h"
#include "include/Sphere.h"

Firework::Firework() : Firework(
    vec3(0, 0, 0),
    vec3(0, 3, 0),
    3 
) {}

Firework::Firework(vec3 pos, vec3 vel, float detTime) {
  pos_ = pos;
  vel_ = vel;
  detTime_ = detTime;
  age_ = 0;
  launch_ = false;
  dead_ = false;
  Setup();
}

Firework::~Firework() {
  if (smokeTrailEmitter_)
    delete smokeTrailEmitter_;
  if (colorTrailEmitter_)
    delete colorTrailEmitter_;
  if (colorExlosionEmitter_)
    delete colorExlosionEmitter_;
  if (colorExlosionEmitter2_)
    delete colorExlosionEmitter2_;
  if (smokeExlosionEmitter_)
    delete smokeExlosionEmitter_;
}


void Firework::Setup() {
  smokeTrailEmitter_ = new DiscEmitter(
      0.1,
      100,
      pos_,
      vec3(0, -1, 0),
      vec3(-1, 0, 0),
      vec3(0, 0 , -1),
      0,
      vec4(1.0, 1.0, 1.0, 1.0),
      0.5,
      5,
      SMOKE,
      0.0f,
      false
  );
  colorTrailEmitter_= new DiscEmitter(
      0.1,
      900,
      pos_,
      vec3(0, -1, 0),
      vec3(-1, 0, 0),
      vec3(0, 0 , -1),
      0,
      vec4(0.4, 0.4, 1.0, 1.0),
      0.05,
      0.2,
      SPARKLE,
      1.0f,
      false
  );

  colorExlosionEmitter_ = new SphereEmitter(
      0.5f,
      50000,
      pos_,
      vec3(0, -1, 0),
      vec3(-1, 0, 0),
      vec3(0, 0 , -1),
      8,
      vec4(0.5, 0, 1.0, 1.0),
      0.1,
      1,
      SPARKLE,
      1.0f,
      false
  );
  colorExlosionEmitter2_ = new SphereEmitter(
      0.5f,
      25000,
      pos_,
      vec3(0, -1, 0),
      vec3(-1, 0, 0),
      vec3(0, 0 , -1),
      2,
      vec4(0.0, 1.0, 0.0, 1.0),
      0.05,
      1,
      SPARKLE,
      1.0f,
      false
  );

  smokeExlosionEmitter_ = new SphereEmitter(
      0.5f,
      9000,
      pos_,
      vec3(0, -1, 0),
      vec3(-1, 0, 0),
      vec3(0, 0 , -1),
      2,
      vec4(1.0, 1.0, 1.0, 1.0),
      1.0,
      4,
      SMOKE,
      0.2f,
      false 
  );
}

void Firework::Update(float dt) {
  if (!launch_)
    return;
  age_ += dt;
  pos_ = pos_ + vel_*dt;
  smokeTrailEmitter_->Pos(pos_);
  colorTrailEmitter_->Pos(pos_);
  colorExlosionEmitter_->Pos(pos_);
  colorExlosionEmitter2_->Pos(pos_);
  smokeExlosionEmitter_->Pos(pos_);
}

void Firework::Emit(Particle* particles, const int& maxP, int& numP, float dt) {
  if (!launch_)
    return;
  if (age_ < detTime_) {
    smokeTrailEmitter_->Emit(particles, maxP, numP, dt);
    colorTrailEmitter_->Emit(particles, maxP, numP, dt);
  }
  else if (age_ >= detTime_ && age_ < detTime_ + 0.1) {
    colorExlosionEmitter_->Emit(particles, maxP, numP, dt);
    colorExlosionEmitter2_->Emit(particles, maxP, numP, dt);
    smokeExlosionEmitter_->Emit(particles, maxP, numP, dt);
  }
  else {
    dead_ = true;
  }
}

