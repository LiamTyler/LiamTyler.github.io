#include "include/Camera.h"

Camera::Camera() {
  pos_ = vec3(0);
  dir_ = vec3(0);
  up_ = vec3(0, 1, 0);
  right_ = cross(dir_, up_);
  vel_linear_ = 1.0f;
  vel_angular_ = 0.005f;
  Setup();
}

Camera::Camera(vec3 pos, vec3 dir, vec3 up) {
  pos_ = pos;
  dir_ = dir;
  up_ = up;
  right_ = cross(dir_, up_);
  Setup();
}

Camera::Camera(vec3 pos, vec3 dir, vec3 up, float vel_linear, float vel_angular) {
  pos_ = pos;
  dir_ = dir;
  up_ = up;
  right_ = cross(dir_, up_);
  vel_linear_ = vel_linear;
  vel_angular_ = vel_angular;
  Setup();
}

void Camera::Setup() {
  // Set View/Projection matrices
  SetView(pos_, dir_, up_);
  SetProjection(radians(45.0f), 4.0f/3.0f, 0.1f, 100.0f); // Defaults for now
}

void Camera::SetProjection(float fov, float aspect, float near_plane,
      float far_plane) {
  projection_ = perspective(fov, aspect, near_plane, far_plane);
}

// Set up the view matrix
void Camera::SetView(vec3 pos, vec3 dir, vec3 up) {
  view_ = lookAt(pos, pos + dir, up);
}

void Camera::Update(float dt) {
  pos_ = pos_ + dt*vel_linear_*vel_.z*dir_ + dt*vel_linear_*vel_.x*right_;
  UpdateViewMatrix();
}

// recalculate view matrix after moving / rotating
void Camera::UpdateViewMatrix() {
  mat4 rot(1);
  rot = rotate(rot, rotation_.y, vec3(0, 1, 0));
  rot = rotate(rot, rotation_.x, vec3(1, 0, 0));
  dir_ = vec3(rot*vec4(0, 0, -1, 0));
  up_ = vec3(rot*vec4(0, 1, 0, 0));
  right_ = cross(dir_, up_);
  SetView(pos_, dir_, up_);
}


// rotate about the Y axis
void Camera::RotateY(float y) {
  rotation_.y += y*vel_angular_;
}

// rotate about the X axis
void Camera::RotateX(float x) {
  rotation_.x += x*vel_angular_;
}
