#include "include/Sphere.h"

Sphere::Sphere() : Sphere(
  vec3(0, 0, 0),
  vec3(0, 0, 0),
  vec3(1, 1, 1),
  vec4(0, 0, 0, 1)
) {}

Sphere::Sphere(vec3 pos, vec3 rot, vec3 scale, vec4 color) {
  pos_ = pos;
  rot_ = rot;
  scale_ = scale;
  color_ = color;
  Setup();
}

void Sphere::Setup() {
  model_ = mat4(1);
  model_ = translate(model_, pos_);
  model_ = rotate(model_, rot_.z, vec3(0, 0, 1));
  model_ = rotate(model_, rot_.x, vec3(1, 0, 0));
  model_ = rotate(model_, rot_.y, vec3(0, 1, 0));
  model_ = scale(model_, scale_);

  LoadVertexObjects();

}

void Sphere::Update(float dt) {
  model_ = mat4(1);
  model_ = translate(model_, pos_);
  model_ = rotate(model_, rot_.z, vec3(0, 0, 1));
  model_ = rotate(model_, rot_.x, vec3(1, 0, 0));
  model_ = rotate(model_, rot_.y, vec3(0, 1, 0));
  model_ = scale(model_, scale_);
}

void Sphere::Draw(mat4 &VP) {
  glUseProgram(object_shader);
  GLint uniVP = glGetUniformLocation(object_shader, "VP");
  GLint uniModel = glGetUniformLocation(object_shader, "model");
  GLint uniScale = glGetUniformLocation(object_shader, "scale");
  glUniformMatrix4fv(uniVP, 1, GL_FALSE, value_ptr(VP));
  glUniformMatrix4fv(uniModel, 1, GL_FALSE, value_ptr(model_));
  glUniform3fv(uniScale, 1, value_ptr(scale_));

  glBindVertexArray(sphere_vao);

  glUniform4fv(glGetUniformLocation(object_shader, "color"), 1,
      value_ptr(color_));

  // glActiveTexture(GL_TEXTURE0);
  // glBindTexture(GL_TEXTURE_2D, normalTex_);
  // glUniform1i(glGetUniformLocation(object_shader, "normalTex"), 1);

  // glDrawArrays(GL_TRIANGLES, 0, 6);
  glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, elementBuffer);
  glDrawElements(GL_TRIANGLES, indices.size(), GL_UNSIGNED_INT, 0);

  // unbind vertex array and shader
  glBindVertexArray(0);
  glUseProgram(0);
}


bool Sphere::IsColliding(vec3 position, float radius, vec3& intersection, vec3&
    surfNormal) {
  float sphereRadius = glm::max(glm::max(scale_.x, scale_.y), scale_.z);
  vec3 distVector = position - pos_;
  surfNormal = normalize(distVector);
  intersection = pos_ + surfNormal*sphereRadius;
  return length(distVector) < radius + sphereRadius;
}
