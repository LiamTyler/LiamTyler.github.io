#include "include/HemisphereEmitter.h"

HemisphereEmitter::HemisphereEmitter(
      float radius,
      float rate,
      vec3 pos,
      vec3 dir,
      vec3 right,
      vec3 up,
      float speed,
      vec4 color,
      float size,
      float lifetime,
      int type,
      float rotSpeed,
      bool useGravity
) : Emitter(
      radius,
      rate,
      pos,
      dir,
      right,
      up,
      speed,
      color,
      size,
      lifetime,
      type,
      rotSpeed,
      useGravity
) {}

vec3 HemisphereEmitter::GetRandomPoint(vec3 &dir) {
  float radius = radius_ * sqrt(((float) rand()) / RAND_MAX);
  float theta = (rand() / (float) RAND_MAX) * 2.0f * M_PI;
  float x = radius * cos(theta);
  float y = radius * sin(theta);
  float z = sqrt(radius_*radius_ - x*x - y*y);
  dir = x * right_ + y * up_ + z * direction_;
  vec3 pos = position_ + dir;
  return pos;
}
